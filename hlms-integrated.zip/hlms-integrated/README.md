# HLMS — Integrated Angular Application

Housing Loan Management System. One Angular 19 application containing the public
site plus all four role portals, built from five independently developed Angular
projects.

```
                         HOME  (/)
                           |
                 +---------+---------+
                 |                   |
             LOGIN (/login)     REGISTER (/register)
                 |
          Authentication (JWT)
                 |
            Identify role
                 |
   +--------+----+-----+--------+
   |        |          |        |
 ADMIN   OFFICER    CUSTOMER   LEGAL
   |        |          |        |
/admin  /officer   /customer  /legal
```

## Run

```bash
npm install
npm start        # http://localhost:4200, proxied to the API Gateway on :8080
npm run build    # production build -> dist/hlms-integrated
```

The backend API Gateway must be listening on `http://localhost:8080`; see
`proxy.conf.json`.

## Modules

| Path | Portal | Source project |
|---|---|---|
| `/`, `/login`, `/register` | Public site | `hlms-angular19-hlms-auth` |
| `/customer/*` | Customer portal | `angular-customer-ui` |
| `/admin/*` | Admin console | `hlms-admin-ui` |
| `/officer/*` | Bank Office portal | `hlms-bankoffice-ui` |
| `/legal/*` | Legal & Valuation portal | `hlms-legal-portal` |

Each module keeps its own `core/` (services, models, guards) exactly as its
original developer wrote it. `src/app/core/` holds the three files added to bind
them together: the shared session, the key registry, and the merged HTTP
interceptor.

See **INTEGRATION_REPORT.md** for the full merge record — every conflict found,
every line changed, and the build/test results.
