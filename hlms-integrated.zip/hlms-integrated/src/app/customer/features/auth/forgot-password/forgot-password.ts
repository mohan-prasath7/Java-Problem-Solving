import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { ToastService } from '../../../core/services/toast.service';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div id="authScreen">
      <div class="auth-wrap">
        <div class="auth-side">
          <img class="auth-image" src="assets/images/hero.png" alt="HLMS" />
        </div>
        <div class="auth-form">
          <span class="back-link" routerLink="/login">← Back to Login</span>

          @if (step() === 1) {
            <h2>Forgot Password</h2>
            <div class="sub">Enter your account email — we'll send a one-time password (OTP) to reset it.</div>
            @if (errorMsg()) {
              <div class="inline-error">{{ errorMsg() }}</div>
            }
            <form [formGroup]="emailForm" (ngSubmit)="sendOtp()">
              <div class="field">
                <label>Email</label>
                <input type="email" formControlName="email" placeholder="you@example.com" />
              </div>
              <button class="btn btn-primary btn-block" type="submit" [disabled]="emailForm.invalid || loading()">
                @if (loading()) {
                  <span class="spinner"></span>
                } @else {
                  Send OTP
                }
              </button>
            </form>
          } @else {
            <h2>Reset Password</h2>
            <div class="sub">Enter the OTP sent to {{ emailForm.value.email }} and choose a new password.</div>
            @if (errorMsg()) {
              <div class="inline-error">{{ errorMsg() }}</div>
            }
            <form [formGroup]="resetForm" (ngSubmit)="reset()">
              <div class="field">
                <label>OTP Code</label>
                <input formControlName="otpCode" placeholder="6-digit code" maxlength="6" />
              </div>
              <div class="field">
                <label>New Password</label>
                <input type="password" formControlName="newPassword" placeholder="Min. 8 characters" />
              </div>
              <button class="btn btn-primary btn-block" type="submit" [disabled]="resetForm.invalid || loading()">
                @if (loading()) {
                  <span class="spinner"></span>
                } @else {
                  Reset Password
                }
              </button>
              <button type="button" class="btn-link" style="margin-top:8px;" (click)="step.set(1)">
                ← Use a different email
              </button>
            </form>
          }
        </div>
      </div>
    </div>
  `
})
export class ForgotPassword {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private toast = inject(ToastService);

  step = signal(1);
  loading = signal(false);
  errorMsg = signal('');

  emailForm = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]]
  });

  resetForm = this.fb.nonNullable.group({
    otpCode: ['', [Validators.required, Validators.pattern(/^\d{4,8}$/)]],
    newPassword: ['', [Validators.required, Validators.minLength(8)]]
  });

  sendOtp(): void {
    if (this.emailForm.invalid) return;
    this.loading.set(true);
    this.errorMsg.set('');
    this.auth.forgotPassword(this.emailForm.getRawValue().email).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.success('OTP sent', 'Check your email/SMS for the reset code.');
        this.step.set(2);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMsg.set(err?.error?.message || 'Could not send OTP. Please check the email and try again.');
      }
    });
  }

  reset(): void {
    if (this.resetForm.invalid) return;
    this.loading.set(true);
    this.errorMsg.set('');
    const { otpCode, newPassword } = this.resetForm.getRawValue();
    this.auth.resetPassword(this.emailForm.getRawValue().email, otpCode, newPassword).subscribe({
      next: () => {
        this.loading.set(false);
        this.toast.success('Password reset', 'You can now log in with your new password.');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.loading.set(false);
        this.errorMsg.set(err?.error?.message || 'Reset failed. The OTP may be invalid or expired.');
      }
    });
  }
}
