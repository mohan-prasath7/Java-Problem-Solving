import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { Notification, ServiceRequest } from '../models/models';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private base = `${environment.apiBase}/notification-service/api`;

  constructor(private http: HttpClient) {}

  // ---- Notifications ----

  listForUser(userEmail: string): Observable<Notification[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<Notification[]>(`${this.base}/notifications`, { params });
  }

  unread(userEmail: string): Observable<Notification[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<Notification[]>(`${this.base}/notifications/unread`, { params });
  }

  markRead(notificationId: string): Observable<Notification> {
    return this.http.patch<Notification>(`${this.base}/notifications/${notificationId}/read`, {});
  }

  // ---- Service requests (e.g. duplicate statement, loan closure letter, NOC) ----

  listServiceRequests(userEmail: string): Observable<ServiceRequest[]> {
    const params = new HttpParams().set('userEmail', userEmail);
    return this.http.get<ServiceRequest[]>(`${this.base}/service-requests`, { params });
  }

  listServiceRequestsForApp(appId: string): Observable<ServiceRequest[]> {
    return this.http.get<ServiceRequest[]>(`${this.base}/service-requests/by-app/${appId}`);
  }

  createServiceRequest(body: {
    userEmail: string;
    appId?: string;
    requestType: string;
    description?: string;
  }): Observable<ServiceRequest> {
    return this.http.post<ServiceRequest>(`${this.base}/service-requests`, body);
  }
}
