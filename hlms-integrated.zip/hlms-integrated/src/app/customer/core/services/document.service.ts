import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { environment } from '../../../../environments/environment';
import { ApplicationDocument, PostDisbursementDocument } from '../models/models';

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private base = `${environment.apiBase}/document-service/api`;

  constructor(private http: HttpClient) {}

  // ---- Application documents before disbursement ----

  listByApp(appId: string): Observable<ApplicationDocument[]> {
    return this.http.get<ApplicationDocument[]>(
      `${this.base}/application-documents/app/${encodeURIComponent(appId)}`
    );
  }

  upload(doc: ApplicationDocument): Observable<ApplicationDocument> {
    return this.http.post<ApplicationDocument>(
      `${this.base}/application-documents`,
      doc
    );
  }

  remove(documentId: string): Observable<string> {
    return this.http.delete(
      `${this.base}/application-documents/${encodeURIComponent(documentId)}`,
      {
        responseType: 'text'
      }
    );
  }

  // ---- Post-disbursement documents ----

  listPostDisbByApp(appId: string): Observable<PostDisbursementDocument[]> {
    return this.http.get<PostDisbursementDocument[]>(
      `${this.base}/post-disbursement-documents/app/${encodeURIComponent(appId)}`
    );
  }

  uploadPostDisb(doc: PostDisbursementDocument): Observable<PostDisbursementDocument> {
    return this.http.post<PostDisbursementDocument>(
      `${this.base}/post-disbursement-documents`,
      doc
    );
  }

  removePostDisb(pdDocId: string): Observable<string> {
    return this.http.delete(
      `${this.base}/post-disbursement-documents/${encodeURIComponent(pdDocId)}`,
      {
        responseType: 'text'
      }
    );
  }
}

/**
 * Reads a browser File into a base64 string without data prefix.
 */
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1] ?? result);
    };

    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/**
 * Downloads a base64 document stored in database.
 */
export function downloadBase64File(
  fileData: string,
  fileName: string,
  mimeType = 'application/octet-stream'
): void {
  const byteCharacters = atob(fileData);
  const byteNumbers = new Array(byteCharacters.length);

  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }

  const byteArray = new Uint8Array(byteNumbers);
  const blob = new Blob([byteArray], { type: mimeType });

  const url = window.URL.createObjectURL(blob);
  const anchor = document.createElement('a');

  anchor.href = url;
  anchor.download = fileName || 'document';
  anchor.click();

  window.URL.revokeObjectURL(url);
}