import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

/** Protects the customer app shell: must be logged in and hold the CUSTOMER role. */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn() && auth.isCustomer()) return true;

  if (auth.isLoggedIn() && !auth.isCustomer()) {
    auth.logout(false);
  }
  router.navigate(['/login']);
  return false;
};

/** Keeps already-logged-in customers out of the public login/register pages. */
export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn() && auth.isCustomer()) {
    router.navigate(['/customer/dashboard']);
    return false;
  }
  return true;
};
