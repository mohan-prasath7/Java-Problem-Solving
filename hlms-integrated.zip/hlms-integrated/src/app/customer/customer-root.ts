import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ToastHost } from './shared/components/toast/toast';

@Component({
  // INTEGRATION CHANGE: renamed from 'app-root' -- this component is now the
  // wrapper for this module's routes, not the application root.
  selector: 'app-customer-root',
  standalone: true,
  imports: [RouterOutlet, ToastHost],
  template: `
    <router-outlet></router-outlet>
    <app-toast-host></app-toast-host>
  `
})
export class App {}
