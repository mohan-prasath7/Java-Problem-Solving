import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/auth/login/login.component';
import { RegisterComponent } from './pages/auth/register/register.component';

/**
 * Public shell of the integrated app: Home, Login, Register.
 * Unchanged from hlms-angular19-hlms-auth's app.routes.ts apart from dropping
 * its '**' catch-all, which now lives in the top-level router.
 */
export const AUTH_ROUTES: Routes = [
  { path: '', component: HomeComponent, title: 'HLMS | Home' },
  { path: 'login', component: LoginComponent, title: 'HLMS | Login' },
  { path: 'register', component: RegisterComponent, title: 'HLMS | Register' }
];
