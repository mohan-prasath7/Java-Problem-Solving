export interface ApplicationDocument {
  documentId?: string;
  appId: string;
  docType: string;
  fileName?: string;
  fileSize?: number;
  // The entity's file bytes (@Lob byte[]) are serialized as a base64 string by
  // Jackson when included in a response - used client-side to render "View".
  fileData?: string;
  // NOTE: the document-service entity's JSON field is "verificationStatus",
  // not "status" - keep these in sync with ApplicationDocumentEntity.
  verificationStatus: 'Pending' | 'Verified' | 'Rejected';
  verifiedBy?: string;
  verifiedAt?: string;
  uploadedAt?: string;
  remarks?: string;
}

export interface PostDisbursementDocument {
  documentId?: number;
  appId: number;
  docType: string;
  fileName?: string;
  status: 'Pending' | 'Verified' | 'Rejected';
  uploadedAt?: string;
}
