import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { ToastService } from '../services/toast.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const toast = inject(ToastService);
  // INTEGRATION CHANGE: this interceptor is now registered app-wide, but its
  // toast host only renders inside the Bank Office wrapper. Scoping it to
  // /officer keeps the original behaviour there and stops it from swallowing
  // error reporting that the other modules handle themselves.
  const router = inject(Router);
  if (!router.url.startsWith('/officer')) return next(req);

  return next(req).pipe(
    catchError((err) => {
      const message = err?.error?.message || err?.message || 'Something went wrong. Please try again.';
      toast.show('Request failed', message, 'error');
      return throwError(() => err);
    })
  );
};
