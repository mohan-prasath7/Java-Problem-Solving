import { Injectable, signal } from '@angular/core';

export interface ToastMsg {
  id: number;
  title: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

let seq = 0;

@Injectable({ providedIn: 'root' })
export class ToastService {
  readonly toasts = signal<ToastMsg[]>([]);

  show(title: string, message: string, type: ToastMsg['type'] = 'info') {
    const toast: ToastMsg = { id: ++seq, title, message, type };
    this.toasts.update(list => [...list, toast]);
    setTimeout(() => this.dismiss(toast.id), 4000);
  }

  dismiss(id: number) {
    this.toasts.update(list => list.filter(t => t.id !== id));
  }
}
