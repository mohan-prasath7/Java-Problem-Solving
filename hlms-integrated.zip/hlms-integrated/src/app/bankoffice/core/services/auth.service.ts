import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap, switchMap, map } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AppUser, LoginRequest, RegisterRequest, UserRole } from '../models/user.model';
import { clearHlmsSession } from '../../../core/session/session-keys';

const STORAGE_KEY = 'hlms_session_v1';

/**
 * Shape user-service actually returns (its appUserEntity), which differs from
 * the AppUser this app uses everywhere else - see toAppUser()/toBackendRole()
 * below for the mapping.
 */
interface BackendUser {
  email: string;
  name: string;
  mobile: string;
  role: 'CUSTOMER' | 'LEGAL' | 'BANK_OFFICER' | 'BIDDER' | 'ADMIN';
  active?: boolean;
  idType?: string;
  idNumber?: string;
  createdAt?: string;
}

// user-service's roleEnum has no EMPLOYEE value - staff accounts are
// LEGAL/BANK_OFFICER/ADMIN. Self-registration only offers customer/bidder
// (see register.component.html), so 'employee' never needs to round-trip here.
const TO_UI_ROLE: Record<BackendUser['role'], UserRole> = {
  CUSTOMER: 'customer',
  LEGAL: 'legal',
  BANK_OFFICER: 'bankoffice',
  BIDDER: 'bidder',
  ADMIN: 'admin'
};

const TO_BACKEND_ROLE: Partial<Record<UserRole, BackendUser['role']>> = {
  customer: 'CUSTOMER',
  legal: 'LEGAL',
  bankoffice: 'BANK_OFFICER',
  bidder: 'BIDDER',
  admin: 'ADMIN'
};

function toAppUser(u: BackendUser): AppUser {
  return {
    fullName: u.name,
    email: u.email,
    phone: u.mobile,
    role: TO_UI_ROLE[u.role] ?? 'customer',
    active: u.active,
    createdAt: u.createdAt
  };
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly baseUrl = `${environment.apiBaseUrl}/user-service/api/users`;
  private readonly otpUrl = `${environment.apiBaseUrl}/user-service/api/otp`;

  /** Currently logged-in user, restored from localStorage on app start. */
  readonly currentUser = signal<AppUser | null>(this.restoreSession());
  readonly isLoggedIn = computed(() => !!this.currentUser());
  readonly role = computed(() => this.currentUser()?.role ?? null);

  constructor(private http: HttpClient) {}

  private restoreSession(): AppUser | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) as AppUser : null;
    } catch {
      return null;
    }
  }

  private persist(user: AppUser | null) {
    if (user) localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    else localStorage.removeItem(STORAGE_KEY);
  }

  // appUserController's /login only returns a JWT ({ token }), not the user
  // record, so we stash the token then fetch the full profile ourselves.
  login(payload: LoginRequest): Observable<AppUser> {
    return this.http.post<{ token?: string }>(`${this.baseUrl}/login`, payload).pipe(
      tap((res) => {
        if (res.token) localStorage.setItem('hlms_token', res.token);
      }),
      switchMap(() => this.http.get<BackendUser>(`${this.baseUrl}/${encodeURIComponent(payload.email)}`)),
      map(toAppUser),
      tap((user) => {
        this.currentUser.set(user);
        this.persist(user);
      })
    );
  }

  register(payload: RegisterRequest): Observable<AppUser> {
    const body = {
      email: payload.email,
      name: payload.fullName,
      mobile: payload.phone,
      password: payload.password,
      role: TO_BACKEND_ROLE[payload.role] ?? 'CUSTOMER'
    };
    return this.http.post<BackendUser>(`${this.baseUrl}/register`, body).pipe(map(toAppUser));
  }

  generateOtp(email: string, purpose = 'PASSWORD_RESET'): Observable<unknown> {
    return this.http.post(`${this.otpUrl}/generate`, { email, purpose });
  }

  verifyOtp(email: string, otp: string): Observable<unknown> {
    return this.http.post(`${this.otpUrl}/verify`, { email, otpCode: otp });
  }

  forgotPassword(email: string): Observable<unknown> {
    return this.http.post(`${this.baseUrl}/forgot-password`, { email });
  }

  resetPassword(email: string, otp: string, newPassword: string): Observable<unknown> {
    return this.http.post(`${this.baseUrl}/reset-password`, { email, otpCode: otp, newPassword });
  }

  updateProfile(email: string, changes: Partial<AppUser>): Observable<AppUser> {
    // appUserController's PUT /{email} takes the full appUserEntity shape back.
    const body = {
      email,
      name: changes.fullName,
      mobile: changes.phone,
      role: changes.role ? (TO_BACKEND_ROLE[changes.role] ?? 'CUSTOMER') : undefined,
      active: changes.active
    };
    return this.http.put<BackendUser>(`${this.baseUrl}/${encodeURIComponent(email)}`, body).pipe(
      map(toAppUser),
      tap((updated) => {
        this.currentUser.set(updated);
        this.persist(updated);
      })
    );
  }

  logout(): void {
    // INTEGRATION CHANGE: also clear the other modules' session keys, otherwise
    // signing out here would leave the other portals still reachable.
    clearHlmsSession();
    this.currentUser.set(null);
    this.persist(null);
    localStorage.removeItem('hlms_token');
  }
}
