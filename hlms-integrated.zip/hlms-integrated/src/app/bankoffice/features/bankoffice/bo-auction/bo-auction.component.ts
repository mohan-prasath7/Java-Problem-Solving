import { Component, inject, signal, computed, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin, of, catchError } from 'rxjs';
import { RepaymentService } from '../../../core/services/repayment.service';
import { LoanService } from '../../../core/services/loan.service';
import { ToastService } from '../../../core/services/toast.service';
import { AuctionCase, Bid } from '../../../core/models/auction.model';
import { LoanApplication } from '../../../core/models/loan-application.model';

const NPA_THRESHOLD = 3; // matches bo-npa's classification rule

interface AuctionRow {
  auction: AuctionCase;
  app: LoanApplication | null;
  bids: Bid[];
}

@Component({
  selector: 'app-bo-auction',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './bo-auction.component.html'
})
export class BoAuctionComponent implements OnInit {
  private repaymentService = inject(RepaymentService);
  private loanService = inject(LoanService);
  private toast = inject(ToastService);

  rows = signal<AuctionRow[]>([]);
  loading = signal(true);
  processingId = signal<number | null>(null);

  // Overdue (3+ installments) accounts not yet in the recovery pipeline -
  // i.e. eligible to be listed for auction but not yet classified as NPA here.
  defaultersEligible = signal<number>(0);

  // Inline "post for auction" form state, keyed by auctionId.
  postingId = signal<number | null>(null);
  reservePrice: number | null = null;
  auctionDate = '';

  live = computed(() => this.rows().filter((r) => r.auction.stage === 'Auction Scheduled'));
  inRecovery = computed(() => this.rows().filter((r) => r.auction.stage !== 'None' && r.auction.stage !== 'Resolved'));
  totalReserve = computed(() => this.rows().reduce((sum, r) => sum + (r.auction.reservePrice || 0), 0));
  totalBids = computed(() => this.live().reduce((sum, r) => sum + r.bids.length, 0));

  ngOnInit(): void {
    this.load();
    this.loadDefaultersEligible();
  }

  private loadDefaultersEligible() {
    this.repaymentService.getOverdue().subscribe({
      next: (appIds) => {
        if (!appIds.length) { this.defaultersEligible.set(0); return; }
        const requests = appIds.map((appId) =>
          forkJoin({
            appId: of(appId),
            schedule: this.repaymentService.getSchedule(appId).pipe(catchError(() => of([]))),
            auction: this.repaymentService.getAuctionForApp(appId).pipe(catchError(() => of(null)))
          })
        );
        forkJoin(requests).subscribe({
          next: (results) => {
            const eligible = results.filter(
              (r) => r.schedule.filter((i) => i.status === 'OVERDUE').length >= NPA_THRESHOLD &&
                (!r.auction || (r.auction as AuctionCase).stage === 'None')
            ).length;
            this.defaultersEligible.set(eligible);
          },
          error: () => this.defaultersEligible.set(0)
        });
      },
      error: () => this.defaultersEligible.set(0)
    });
  }

  load() {
    this.loading.set(true);
    this.repaymentService.getAuctions().subscribe({
      next: (auctions) => {
        if (!auctions.length) { this.rows.set([]); this.loading.set(false); return; }
        this.loanService.getAllApplications().subscribe({
          next: (apps) => {
            const requests = auctions.map((auction) =>
              forkJoin({
                auction: of(auction),
                bids: auction.stage === 'Auction Scheduled'
                  ? this.repaymentService.getBidsForApp(auction.appId).pipe(catchError(() => of([])))
                  : of([] as Bid[])
              })
            );
            forkJoin(requests).subscribe({
              next: (results) => {
                const rows: AuctionRow[] = results.map(({ auction, bids }) => ({
                  auction,
                  app: apps.find((a) => String(a.appId) === String(auction.appId)) ?? null,
                  bids: bids.slice().sort((a, b) => b.bidAmount - a.bidAmount)
                }));
                this.rows.set(rows);
                this.loading.set(false);
              },
              error: () => { this.rows.set([]); this.loading.set(false); }
            });
          },
          error: () => { this.rows.set([]); this.loading.set(false); }
        });
      },
      error: () => { this.rows.set([]); this.loading.set(false); }
    });
  }

  stageBadge(stage: AuctionCase['stage']): string {
    if (stage === 'Resolved') return 'badge-green';
    if (stage === 'Auction Scheduled') return 'badge-navy';
    if (stage === 'Possession') return 'badge-orange';
    return 'badge-gray';
  }

  highestBid(row: AuctionRow): Bid | null {
    return row.bids.length ? row.bids[0] : null;
  }

  recordPossession(row: AuctionRow) {
    if (!row.auction.auctionId) return;
    this.processingId.set(row.auction.auctionId);
    this.repaymentService.updateAuction(row.auction.auctionId, {
      ...row.auction,
      stage: 'Possession',
      possessionDate: new Date().toISOString().slice(0, 10)
    }).subscribe({
      next: () => { this.processingId.set(null); this.toast.show('Possession Recorded', 'Symbolic possession has been recorded.', 'success'); this.load(); },
      error: () => { this.processingId.set(null); this.toast.show('Error', 'Could not update auction case.', 'error'); }
    });
  }

  startPostForAuction(row: AuctionRow) {
    this.postingId.set(row.auction.auctionId ?? null);
    this.reservePrice = row.app?.propertyValue ?? null;
    const twoWeeksOut = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
    this.auctionDate = twoWeeksOut.toISOString().slice(0, 10);
  }

  cancelPostForAuction() {
    this.postingId.set(null);
    this.reservePrice = null;
    this.auctionDate = '';
  }

  confirmPostForAuction(row: AuctionRow) {
    if (!row.auction.auctionId) return;
    if (!this.reservePrice || !this.auctionDate) {
      this.toast.show('Missing details', 'Please provide a reserve price and auction date.', 'error');
      return;
    }
    this.processingId.set(row.auction.auctionId);
    this.repaymentService.updateAuction(row.auction.auctionId, {
      ...row.auction,
      stage: 'Auction Scheduled',
      reservePrice: this.reservePrice,
      auctionDate: this.auctionDate
    }).subscribe({
      next: () => {
        this.processingId.set(null);
        this.toast.show('Posted for e-Auction', 'Now live on the Bidder Portal.', 'success');
        this.cancelPostForAuction();
        this.load();
      },
      error: () => { this.processingId.set(null); this.toast.show('Error', 'Could not post for auction.', 'error'); }
    });
  }

  resolve(row: AuctionRow) {
    if (!row.auction.auctionId) return;
    if (!confirm('Mark this recovery case as Resolved / Withdrawn?')) return;
    this.processingId.set(row.auction.auctionId);
    this.repaymentService.updateAuction(row.auction.auctionId, {
      ...row.auction,
      stage: 'Resolved'
    }).subscribe({
      next: () => { this.processingId.set(null); this.toast.show('Case Resolved', 'Marked as resolved / withdrawn.', 'success'); this.load(); },
      error: () => { this.processingId.set(null); this.toast.show('Error', 'Could not update auction case.', 'error'); }
    });
  }
}
