import { Injectable, signal } from '@angular/core';

export interface ToastMessage {
  id: number;
  title: string;
  body?: string;
  type: 'success' | 'error' | 'info';
}

let nextId = 1;

@Injectable({ providedIn: 'root' })
export class ToastService {
  toasts = signal<ToastMessage[]>([]);

  show(title: string, body?: string, type: ToastMessage['type'] = 'info'): void {
    const toast: ToastMessage = { id: nextId++, title, body, type };
    this.toasts.update((list) => [...list, toast]);
    setTimeout(() => this.dismiss(toast.id), 4500);
  }

  success(title: string, body?: string): void { this.show(title, body, 'success'); }
  error(title: string, body?: string): void { this.show(title, body, 'error'); }

  dismiss(id: number): void {
    this.toasts.update((list) => list.filter((t) => t.id !== id));
  }
}
