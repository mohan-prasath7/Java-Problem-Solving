import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { LegalVerificationDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class LegalVerificationService {
  private base = `${environment.apiBase}/legal-service/api/legal/verifications`;

  constructor(private http: HttpClient) {}

  /** Returns null instead of throwing when no verification record exists yet for this application. */
  getByApplication(appId: string): Observable<LegalVerificationDTO | null> {
    return this.http.get<LegalVerificationDTO>(`${this.base}/by-application/${appId}`).pipe(
      catchError(() => of(null))
    );
  }

  create(dto: LegalVerificationDTO): Observable<LegalVerificationDTO> {
    return this.http.post<LegalVerificationDTO>(this.base, dto);
  }

  update(verificationId: number, dto: LegalVerificationDTO): Observable<LegalVerificationDTO> {
    return this.http.put<LegalVerificationDTO>(`${this.base}/${verificationId}`, dto);
  }
}
