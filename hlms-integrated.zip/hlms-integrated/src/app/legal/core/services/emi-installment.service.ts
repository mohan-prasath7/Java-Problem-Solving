import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { EmiInstallmentDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class EmiInstallmentService {
  private base = `${environment.apiBase}/repayment-service/api/emi`;

  constructor(private http: HttpClient) {}

  getSchedule(appId: string): Observable<EmiInstallmentDTO[]> {
    return this.http.get<EmiInstallmentDTO[]>(`${this.base}/${appId}/schedule`);
  }
}
