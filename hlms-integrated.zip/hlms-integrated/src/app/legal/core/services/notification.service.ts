import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { NotificationDTO } from '../models/models';

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private base = `${environment.apiBase}/notification-service/api/notifications`;

  constructor(private http: HttpClient) {}

  /** Sends an in-app/email/sms notification to a user (e.g. the borrower) about a legal action. */
  send(userEmail: string, title: string, body: string, channels: string[] = ['inapp']): Observable<NotificationDTO | null> {
    return this.http.post<NotificationDTO>(this.base, { userEmail, title, body, channels }).pipe(
      catchError(() => of(null))
    );
  }
}
