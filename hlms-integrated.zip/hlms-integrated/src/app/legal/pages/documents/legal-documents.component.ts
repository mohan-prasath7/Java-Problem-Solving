import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AuthService } from '../../core/services/auth.service';
import { ToastService } from '../../core/services/toast.service';
import { DocumentService } from '../../core/services/document.service';
import { LoanApplicationService } from '../../core/services/loan-application.service';
import { NotificationService } from '../../core/services/notification.service';
import { ApplicationDocumentEntity, LoanApplication, PostDisbursementDocumentEntity } from '../../core/models/models';

interface PdRow extends PostDisbursementDocumentEntity { trackingNo: string; applicantName: string; userEmail: string; }
interface AppDocRow extends ApplicationDocumentEntity { trackingNo: string; applicantName: string; }

@Component({
  selector: 'app-legal-documents',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './legal-documents.component.html'
})
export class LegalDocumentsComponent implements OnInit {
  loading = signal(true);
  pdRows = signal<PdRow[]>([]);
  appDocRows = signal<AppDocRow[]>([]);

  rejectModalOpen = signal(false);
  rejectTarget = signal<PdRow | null>(null);
  rejectRemarks = '';
  rejectError = signal<string | null>(null);

  constructor(
    public auth: AuthService,
    private toast: ToastService,
    private docSvc: DocumentService,
    private loanSvc: LoanApplicationService,
    private notifSvc: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  private loadAll(): void {
    this.loading.set(true);
    forkJoin({
      apps: this.loanSvc.listAll(),
      pdDocs: this.docSvc.listAllPostDisbursementDocuments(),
      appDocs: this.docSvc.listAllApplicationDocuments()
    }).subscribe(({ apps, pdDocs, appDocs }) => {
      const byId = new Map<string, LoanApplication>(apps.map((a) => [a.appId, a]));
      this.pdRows.set(
        pdDocs
          .map((d) => ({ ...d, trackingNo: byId.get(d.appId)?.trackingNo || d.appId, applicantName: byId.get(d.appId)?.applicantName || '—', userEmail: byId.get(d.appId)?.userEmail || '' }))
          .sort((a, b) => new Date(b.uploadedAt || 0).getTime() - new Date(a.uploadedAt || 0).getTime())
      );
      this.appDocRows.set(
        appDocs
          .map((d) => ({ ...d, trackingNo: byId.get(d.appId)?.trackingNo || d.appId, applicantName: byId.get(d.appId)?.applicantName || '—' }))
          .sort((a, b) => new Date(b.uploadedAt || 0).getTime() - new Date(a.uploadedAt || 0).getTime())
      );
      this.loading.set(false);
    });
  }

  pendingPdCount(): number {
    return this.pdRows().filter((d) => d.status === 'Pending').length;
  }

  badgeClass(status: string): string {
    return status === 'Verified' ? 'badge-green' : status === 'Rejected' ? 'badge-red' : 'badge-orange';
  }

  viewDoc(doc: { fileData?: string; fileName: string }): void {
    this.docSvc.openInlineDocument(doc);
  }

  verify(row: PdRow): void {
    const officer = this.auth.currentUser();
    if (!officer) return;
    this.docSvc.verifyPostDisbursementDocument(row, officer.name).subscribe({
      next: () => {
        this.toast.success('Document Verified', row.fileName);
        this.notifSvc.send(row.userEmail, 'Document Verified',
          `Your document "${row.docType}" (${row.fileName}) has been verified by the Legal & Valuation Team.`).subscribe();
        this.loadAll();
      },
      error: () => this.toast.error('Could not verify document', 'Please try again.')
    });
  }

  openReject(row: PdRow): void {
    this.rejectTarget.set(row);
    this.rejectRemarks = '';
    this.rejectError.set(null);
    this.rejectModalOpen.set(true);
  }

  closeReject(): void {
    this.rejectModalOpen.set(false);
    this.rejectTarget.set(null);
  }

  confirmReject(): void {
    const row = this.rejectTarget();
    const officer = this.auth.currentUser();
    if (!row || !officer) return;
    if (!this.rejectRemarks.trim()) {
      this.rejectError.set('Please provide a reason for rejection.');
      return;
    }
    this.docSvc.rejectPostDisbursementDocument(row, officer.name, this.rejectRemarks.trim()).subscribe({
      next: () => {
        this.toast.success('Document Rejected', row.fileName);
        this.notifSvc.send(row.userEmail, 'Document Rejected',
          `Your document "${row.docType}" (${row.fileName}) was rejected by the Legal & Valuation Team. Reason: ${this.rejectRemarks.trim()}. Please re-upload from Post Disbursement.`).subscribe();
        this.closeReject();
        this.loadAll();
      },
      error: () => this.rejectError.set('Could not reject document. Please try again.')
    });
  }
}
