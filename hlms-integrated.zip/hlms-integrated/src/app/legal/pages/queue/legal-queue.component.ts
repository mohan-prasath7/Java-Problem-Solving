import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { LegalDataService } from '../../core/services/legal-data.service';
import { LegalQueueRow } from '../../core/models/models';

@Component({
  selector: 'app-legal-queue',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './legal-queue.component.html'
})
export class LegalQueueComponent implements OnInit {
  loading = signal(true);
  ready = signal<LegalQueueRow[]>([]);
  locked = signal<LegalQueueRow[]>([]);
  resolved = signal<LegalQueueRow[]>([]);

  constructor(private legalData: LegalDataService) {}

  ngOnInit(): void {
    forkJoin({
      queue: this.legalData.getQueue(),
      resolved: this.legalData.getRecentlyActioned()
    }).subscribe(({ queue, resolved }) => {
      this.ready.set(queue.ready);
      this.locked.set(queue.locked);
      this.resolved.set(
        resolved.slice().sort((a, b) => {
          const ad = a.verification?.decisionDate ? new Date(a.verification.decisionDate).getTime() : 0;
          const bd = b.verification?.decisionDate ? new Date(b.verification.decisionDate).getTime() : 0;
          return bd - ad;
        }).slice(0, 10)
      );
      this.loading.set(false);
    });
  }

  decisionBadgeClass(decision: string | null | undefined): string {
    if (decision === 'Approved') return 'badge-green';
    if (decision === 'Rejected') return 'badge-red';
    if (decision === 'Query Raised') return 'badge-orange';
    return 'badge-gray';
  }
}
