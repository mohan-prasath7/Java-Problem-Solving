import { Component, OnInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthService } from './core/services/auth.service';
import { ToastComponent } from './layout/toast/toast.component';

@Component({
  // INTEGRATION CHANGE: renamed from 'app-root' -- this component is now the
  // wrapper for this module's routes, not the application root.
  selector: 'app-legal-root',
  standalone: true,
  imports: [RouterOutlet, ToastComponent],
  template: `
    @if (auth.authReady()) {
      <router-outlet></router-outlet>
    } @else {
      <div class="app-loading">Loading HLMS Legal Portal…</div>
    }
    <app-toast></app-toast>
  `
})
export class AppComponent implements OnInit {
  constructor(public auth: AuthService) {}

  ngOnInit(): void {
    this.auth.restoreSession().subscribe();
  }
}
