import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';

import { AuthService } from '../services/auth.service';

/** Blocks access unless a valid, non-expired session is present. */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isLoggedIn()) return true;

  return auth.restoreSession().pipe(
    map((user) => (user ? true : router.createUrlTree(['/login'])))
  );
};

/**
 * Blocks access unless the signed-in user's role (from the JWT) is ADMIN.
 * This UI is the admin-only console, so any other role gets logged out
 * and sent back to login with an explanatory message.
 */
export const adminGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const proceed = (): boolean | ReturnType<Router['createUrlTree']> => {
    if (auth.isAdmin()) return true;
    auth.logout();
    return router.createUrlTree(['/login'], { queryParams: { reason: 'not-admin' } });
  };

  if (auth.isLoggedIn()) return proceed();

  return auth.restoreSession().pipe(map(() => proceed()));
};
