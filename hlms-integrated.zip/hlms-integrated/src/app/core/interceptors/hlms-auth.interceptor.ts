import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

import { TOKEN_KEYS, clearHlmsSession } from '../session/session-keys';

/**
 * INTEGRATION LAYER - replaces the five per-module auth interceptors.
 *
 * All five did the same two things, differing only in which localStorage key
 * they read and whether they handled 401:
 *
 *   auth        : attach 'hlms_auth_token'
 *   customer    : attach 'hlms_token', skip a public-endpoint allowlist,
 *                 on 401 -> logout + /login?sessionExpired=1
 *   admin       : attach 'hlms_admin_token' when the URL targets the gateway
 *   bank office : attach 'hlms_token'
 *   legal       : attach 'hlms_legal_token', on 401 -> logout + /login
 *
 * Interceptors registered in app.config run for EVERY request regardless of
 * which module made it, so five of them stacked would each try to set the same
 * header. They are merged here into one that keeps the union of the behaviour:
 * read whichever token key is populated, honour the customer module's public
 * allowlist, and treat a 401 as a session-wide sign-out.
 */

/**
 * Endpoints the backend serves without a JWT. Taken verbatim from the customer
 * module's interceptor -- sending a stale Authorization header to these caused
 * avoidable 401s on the public home / guidance pages.
 */
const PUBLIC_API_URLS = [
  '/loan-service/api/loan-products',
  '/loan-service/api/loan-products/',
  '/loan-service/api/loan-guidance/recommendations',
  '/loan-service/api/loan-guidance/emi-assistant',
  '/user-service/api/users/login',
  '/user-service/api/users/register',
  '/user-service/api/users/forgot-password',
  '/user-service/api/users/reset-password'
];

function readToken(): string | null {
  for (const k of TOKEN_KEYS) {
    const t = localStorage.getItem(k);
    if (t) return t;
  }
  return null;
}

export const hlmsAuthInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);

  const isPublicApi = PUBLIC_API_URLS.some((url) => req.url.includes(url));
  const token = readToken();

  const authedReq =
    token && !isPublicApi
      ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } })
      : req;

  return next(authedReq).pipe(
    catchError((err) => {
      if (err?.status === 401 && !isPublicApi) {
        // The JWT is shared across all four portals, so an expired/rejected
        // token invalidates every module's session, not just this one.
        clearHlmsSession();
        router.navigate(['/login'], { queryParams: { sessionExpired: 1 } });
      }
      return throwError(() => err);
    })
  );
};
