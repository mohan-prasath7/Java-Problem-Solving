/**
 * Unified environment for the integrated HLMS app.
 *
 * The five source projects used two different property names for the same
 * value -- `apiBaseUrl` (auth / admin / bank-office) and `apiBase`
 * (customer / legal). BOTH are kept here with the same value so that every
 * service that was written against either name keeps working untouched.
 *
 * Both are '' so that every service URL stays relative (e.g.
 * "/user-service/api/users/login"). Relative requests hit the Angular dev
 * server, which proxy.conf.json forwards to the Spring Cloud API Gateway on
 * localhost:8080. The gateway strips the "/<service-name>" prefix and routes
 * to the matching Eureka service.
 */
export const environment = {
  production: true,

  apiBaseUrl: '',   // used by: auth, admin, bank-office services
  apiBase: '',      // used by: customer, legal services

  services: {
    user: '/user-service',
    loan: '/loan-service',
    legal: '/legal-service',
    repayment: '/repayment-service',
    notification: '/notification-service',
    document: '/document-service'
  }
};
