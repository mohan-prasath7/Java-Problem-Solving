package com.hlms.repayment.repository;

import com.hlms.repayment.entity.AuctionNote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AuctionNoteRepository extends JpaRepository<AuctionNote, String> {
    List<AuctionNote> findByAppIdAndDeletedAtIsNullOrderByNoteDateDesc(String appId);
}
