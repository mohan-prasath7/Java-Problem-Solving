package com.hlms.repayment.service;
import com.hlms.repayment.client.NotificationClient;
import com.hlms.repayment.client.NotificationRequest;
import com.hlms.repayment.entity.EmiInstallment;
import com.hlms.repayment.entity.LoanApplication;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
/**
 * US-NM-04 Reminder Notifications + the daily sweeps that keep Feature 10 (Default
 * Management) live without any manual trigger. No schema change: this only reads/writes
 * rows in tables that already exist (emi_installment, notification, audit_log, legal_notice).
 */
@Service
public class ReminderSchedulerService {
    private final com.hlms.repayment.repository.EmiInstallmentRepository emiInstallmentRepository;
    private final com.hlms.repayment.repository.LoanApplicationRepository loanApplicationRepository;
    private final NotificationClient notificationClient;
    private final EmiService emiService;
    private final DefaultManagementService defaultManagementService;
    private final AuditService auditService;
    /** US-NM-04: every morning, reminds customers of EMIs due in the next 3 days.
     *  Dedupe via audit_log so the same installment isn't reminded twice on the same day. */
    @Scheduled(cron = "0 0 8 * * *")
    public void sendUpcomingEmiReminders() {
        LocalDate today = LocalDate.now();
        List<EmiInstallment> dueSoon = emiInstallmentRepository
                .findByStatusAndDueDateBetweenAndDeletedAtIsNull("Due", today, today.plusDays(3));
        for (EmiInstallment installment : dueSoon) {
            if (alreadyRemindedToday(installment.getInstallmentId())) continue;
            LoanApplication app = loanApplicationRepository.findById(installment.getAppId()).orElse(null);
            if (app == null) continue;
            notificationClient.send(new NotificationRequest(app.getUserEmail(), "EMI due soon",
                    "Installment #" + installment.getInstallmentNo() + " of " + installment.getEmiAmount()
                            + " is due on " + installment.getDueDate() + " for application " + app.getAppId() + ".",
                    List.of("inapp", "sms", "email")));
            auditService.record("emi_installment", installment.getInstallmentId(), "REMINDER_SENT", "system",
                    null, java.util.Map.of("dueDate", installment.getDueDate().toString()));
        }
        log.info("EMI reminder sweep complete: {} installment(s) considered.", dueSoon.size());
    }
    /** US-DMNG-01: marks Due installments past their due date as Overdue. */
    @Scheduled(cron = "0 30 0 * * *")
    public void sweepOverdueInstallments() {
        int updated = emiService.markOverdueInstallments();
        log.info("Overdue sweep complete: {} installment(s) marked Overdue.", updated);
    }
    /** US-DMNG-04/05: escalates default handling for accounts whose overdue severity increased. */
    @Scheduled(cron = "0 0 1 * * *")
    public void sweepDefaultEscalation() {
        var escalated = defaultManagementService.runEscalationCheck();
        log.info("Default escalation sweep complete: {} application(s) escalated.", escalated.size());
    }
    private boolean alreadyRemindedToday(String installmentId) {
        return auditService.history("emi_installment", installmentId).stream()
                .anyMatch(a -> "REMINDER_SENT".equals(a.getAction())
                        && a.getCreatedAt().toLocalDate().equals(LocalDate.now()));
    }

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(ReminderSchedulerService.class);

    public ReminderSchedulerService(com.hlms.repayment.repository.EmiInstallmentRepository emiInstallmentRepository, com.hlms.repayment.repository.LoanApplicationRepository loanApplicationRepository, NotificationClient notificationClient, EmiService emiService, DefaultManagementService defaultManagementService, AuditService auditService) {
        this.emiInstallmentRepository = emiInstallmentRepository;
        this.loanApplicationRepository = loanApplicationRepository;
        this.notificationClient = notificationClient;
        this.emiService = emiService;
        this.defaultManagementService = defaultManagementService;
        this.auditService = auditService;
    }
}