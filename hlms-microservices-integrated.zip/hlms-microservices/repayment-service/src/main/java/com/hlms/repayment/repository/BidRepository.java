package com.hlms.repayment.repository;

import com.hlms.repayment.entity.Bid;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BidRepository extends JpaRepository<Bid, String> {
    List<Bid> findByAppIdAndDeletedAtIsNullOrderByBidAmountDesc(String appId);
    List<Bid> findByBidderEmailAndDeletedAtIsNull(String bidderEmail);
}
