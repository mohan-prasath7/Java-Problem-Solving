package com.hlms.repayment.client;

/** Response/request shape for legal-service's internal endpoint. */
public record LegalStatusResponse(String appId, boolean verificationExists, String decision, String officer) { }
