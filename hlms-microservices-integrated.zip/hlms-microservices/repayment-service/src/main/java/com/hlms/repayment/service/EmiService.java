package com.hlms.repayment.service;
import com.hlms.repayment.entity.EmiInstallment;
import com.hlms.repayment.exception.BadRequestException;
import com.hlms.repayment.exception.ResourceNotFoundException;
import com.hlms.repayment.repository.EmiInstallmentRepository;
import com.hlms.repayment.util.EmiMathUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
/** Backs feature "7. Loan Repayment Monitoring". */
@Service
public class EmiService {
    private final EmiInstallmentRepository repository;
    /** US-LRM-02: builds the full amortization schedule for a freshly-disbursed loan. */
    @Transactional
    public List<EmiInstallment> generateSchedule(String appId, BigDecimal principal, BigDecimal annualRatePercent,
                                                  int tenureYears, LocalDate firstDueDate) {
        BigDecimal emi = EmiMathUtil.emiForLoan(principal, annualRatePercent, tenureYears);
        BigDecimal monthlyRate = annualRatePercent.divide(BigDecimal.valueOf(1200), 10, RoundingMode.HALF_UP);
        BigDecimal balance = principal;
        List<EmiInstallment> schedule = new ArrayList<>();
        int totalMonths = tenureYears * 12;
        for (int i = 1; i <= totalMonths; i++) {
            BigDecimal interest = balance.multiply(monthlyRate).setScale(2, RoundingMode.HALF_UP);
            BigDecimal principalComponent = emi.subtract(interest).setScale(2, RoundingMode.HALF_UP);
            balance = balance.subtract(principalComponent).max(BigDecimal.ZERO);
            EmiInstallment installment = EmiInstallment.builder()
                    .installmentId(appId + "-EMI-" + i)
                    .appId(appId)
                    .installmentNo(i)
                    .dueDate(firstDueDate.plusMonths(i - 1))
                    .emiAmount(emi)
                    .principalComponent(principalComponent)
                    .interestComponent(interest)
                    .closingBalance(balance)
                    .status("Due")
                    .build();
            schedule.add(installment);
        }
        return repository.saveAll(schedule);
    }
    public List<EmiInstallment> getSchedule(String appId) {
        return repository.findByAppIdAndDeletedAtIsNullOrderByInstallmentNoAsc(appId);
    }
    /** US-LRM-01/03: records a payment against an installment and updates its status. */
    @Transactional
    public EmiInstallment recordPayment(String installmentId, LocalDate paidDate) {
        EmiInstallment installment = repository.findById(installmentId)
                .filter(e -> e.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("EMI installment not found: " + installmentId));
        if ("Paid".equals(installment.getStatus())) {
            throw new BadRequestException("This installment has already been paid.");
        }
        installment.setStatus("Paid");
        installment.setPaidDate(paidDate);
        return repository.save(installment);
    }
    public BigDecimal outstandingBalance(String appId) {
        return getSchedule(appId).stream()
                .filter(e -> !"Paid".equals(e.getStatus()))
                .map(EmiInstallment::getEmiAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    /** US-DMNG-01: marks any installment past its due date and still unpaid as Overdue. */
    @Transactional
    public int markOverdueInstallments() {
        LocalDate today = LocalDate.now();
        List<EmiInstallment> due = repository.findByStatusAndDeletedAtIsNull("Due");
        int updated = 0;
        for (EmiInstallment e : due) {
            if (e.getDueDate().isBefore(today)) {
                e.setStatus("Overdue");
                repository.save(e);
                updated++;
            }
        }
        return updated;
    }

    public EmiService(EmiInstallmentRepository repository) {
        this.repository = repository;
    }
}