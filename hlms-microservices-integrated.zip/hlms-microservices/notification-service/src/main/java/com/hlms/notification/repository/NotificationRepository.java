package com.hlms.notification.repository;

import com.hlms.notification.entity.Notification;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, String> {
    List<Notification> findByUserEmailAndDeletedAtIsNullOrderByCreatedAtDesc(String userEmail);
    List<Notification> findByUserEmailAndIsReadAndDeletedAtIsNull(String userEmail, Boolean isRead);
    // Cross-cutting: paginated variant for larger notification histories.
    Page<Notification> findByUserEmailAndDeletedAtIsNull(String userEmail, Pageable pageable);
}
