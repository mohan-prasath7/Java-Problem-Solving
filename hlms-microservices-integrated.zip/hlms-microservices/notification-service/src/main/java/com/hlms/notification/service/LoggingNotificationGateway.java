package com.hlms.notification.service;
import org.springframework.stereotype.Service;
/**
 * Default NotificationGateway: logs what would have been sent instead of calling a real
 * SMS/email/push provider (no such provider credentials exist in this environment).
 * This is the seam to plug a real gateway into later - see NotificationGateway's javadoc.
 */
@Service
public class LoggingNotificationGateway implements NotificationGateway {
    @Override
    public void dispatch(String channel, String userEmail, String title, String body) {
        switch (channel) {
            case "sms" -> log.info("[SMS -> {}] {}: {}", userEmail, title, body);
            case "email" -> log.info("[EMAIL -> {}] Subject: {} | Body: {}", userEmail, title, body);
            case "inapp" -> log.info("[IN-APP -> {}] {}: {}", userEmail, title, body);
            default -> log.info("[{} -> {}] {}: {}", channel, userEmail, title, body);
        }
    }

    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(LoggingNotificationGateway.class);
}