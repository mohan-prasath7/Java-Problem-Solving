package com.hlms.notification.client;

/** Response/request shape for repayment-service's internal endpoint. */
public record RepaymentSummaryResponse(String appId, int totalInstallments, int paidInstallments, int overdueInstallments, boolean inDefault) { }
