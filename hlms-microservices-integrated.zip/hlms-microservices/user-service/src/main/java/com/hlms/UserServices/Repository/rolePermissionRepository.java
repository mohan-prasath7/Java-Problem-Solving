package com.hlms.UserServices.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hlms.UserServices.Entity.rolePermissionEntity;

@Repository
public interface rolePermissionRepository
        extends JpaRepository<rolePermissionEntity, Long> {

    Optional<rolePermissionEntity>
    findByRoleAndModule(
            String role,
            String module);

    List<rolePermissionEntity>
    findByRole(
            String role);
}