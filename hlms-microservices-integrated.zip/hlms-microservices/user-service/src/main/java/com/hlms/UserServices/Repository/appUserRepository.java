package com.hlms.UserServices.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hlms.UserServices.Entity.appUserEntity;

@Repository
public interface appUserRepository
        extends JpaRepository<appUserEntity, String> {

    Optional<appUserEntity>
    findByEmailAndDeletedAtIsNull(
            String email);

    boolean existsByEmail(
            String email);
}