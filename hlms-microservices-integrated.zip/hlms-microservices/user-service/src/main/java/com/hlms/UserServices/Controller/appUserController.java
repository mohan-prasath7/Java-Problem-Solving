package com.hlms.UserServices.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.hlms.UserServices.Dto.ForgotPasswordDTO;
import com.hlms.UserServices.Dto.LoginRequestDTO;
import com.hlms.UserServices.Dto.LoginResponseDTO;
import com.hlms.UserServices.Dto.RegisterRequestDTO;
import com.hlms.UserServices.Dto.ResetPasswordDTO;
import com.hlms.UserServices.Entity.appUserEntity;
import com.hlms.UserServices.Service.appUserService;

@RestController
@RequestMapping("/api/users")
public class appUserController {

    @Autowired
    private appUserService service;

    @PostMapping("/register")
    public ResponseEntity<appUserEntity>
    register(
            @RequestBody
            RegisterRequestDTO request) {

        return new ResponseEntity<>(
                service.registerUser(
                        request),
                HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO>
    login(
            @RequestBody
            LoginRequestDTO request) {

        return ResponseEntity.ok(
                service.login(
                        request));
    }

    @GetMapping("/{email}")
    public ResponseEntity<appUserEntity>
    getUser(
            @PathVariable
            String email) {

        return ResponseEntity.ok(
                service.getUserByEmail(
                        email));
    }

    @PutMapping("/{email}")
    public ResponseEntity<appUserEntity>
    updateUser(
            @PathVariable
            String email,

            @RequestBody
            appUserEntity user) {

        return ResponseEntity.ok(
                service.updateUser(
                        email,
                        user));
    }

    @DeleteMapping("/{email}")
    public ResponseEntity<String>
    deleteUser(
            @PathVariable
            String email) {

        service.deleteUser(
                email);

        return ResponseEntity.ok(
                "User Deleted");
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String>
    forgotPassword(
            @RequestBody
            ForgotPasswordDTO dto) {

        return ResponseEntity.ok(
                service.forgotPassword(
                        dto.getEmail()));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<String>
    resetPassword(
            @RequestBody
            ResetPasswordDTO dto) {

        return ResponseEntity.ok(
                service.resetPassword(
                        dto.getEmail(),
                        dto.getOtpCode(),
                        dto.getNewPassword()));
    }
}