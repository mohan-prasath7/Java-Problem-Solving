package com.hlms.UserServices.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.hlms.UserServices.Entity.rolePermissionEntity;
import com.hlms.UserServices.Service.rolePermissionService;

@RestController
@RequestMapping("/api/role-permissions")
public class rolePermissionController {

    @Autowired
    private rolePermissionService service;

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<rolePermissionEntity>
    createPermission(
            @RequestBody
            rolePermissionEntity permission) {

        return ResponseEntity.ok(
                service.createPermission(permission));
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<rolePermissionEntity>>
    getAllPermissions() {

        return ResponseEntity.ok(
                service.getAllPermissions());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<rolePermissionEntity>
    getPermission(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                service.getPermission(id));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<rolePermissionEntity>
    updatePermission(
            @PathVariable Long id,
            @RequestBody rolePermissionEntity permission) {

        return ResponseEntity.ok(
                service.updatePermission(id, permission));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String>
    deletePermission(
            @PathVariable Long id) {

        service.deletePermission(id);

        return ResponseEntity.ok(
                "Permission Deleted Successfully");
    }
}