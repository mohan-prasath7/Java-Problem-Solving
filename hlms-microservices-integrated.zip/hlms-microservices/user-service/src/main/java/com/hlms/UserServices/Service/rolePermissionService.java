package com.hlms.UserServices.Service;

import java.util.List;

import com.hlms.UserServices.Entity.rolePermissionEntity;

public interface rolePermissionService {

    rolePermissionEntity createPermission(
            rolePermissionEntity permission);

    List<rolePermissionEntity> getAllPermissions();

    rolePermissionEntity getPermission(
            Long permissionId);

    rolePermissionEntity updatePermission(
            Long permissionId,
            rolePermissionEntity permission);

    void deletePermission(
            Long permissionId);
}