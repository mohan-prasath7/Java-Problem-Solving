package com.hlms.UserServices.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hlms.UserServices.Dto.UserSummaryResponse;
import com.hlms.UserServices.Entity.appUserEntity;
import com.hlms.UserServices.Service.appUserService;

/**
 * Service-to-service endpoint (not for end users): every other HLMS microservice
 * calls this through its own Feign UserClient (resolved via Eureka as "user-service")
 * whenever it needs user identity, role, or contact info - so this remains the single
 * source of truth for all user-related data, per the HLMS integration requirements.
 *
 * Delegates straight to the existing appUserService/appUserServiceImplementation -
 * no business logic is duplicated or changed here, this controller only reshapes the
 * existing appUserEntity into the shared UserSummaryResponse contract callers expect.
 *
 * Protected by InternalApiKeyFilter (X-Internal-Api-Key header) instead of the normal
 * JWT flow, matching the same /internal/** pattern already used by every other HLMS
 * microservice's InternalXxxController.
 */
@RestController
@RequestMapping("/internal/users")
public class InternalUserController {

    @Autowired
    private appUserService service;

    @GetMapping("/{email}")
    public UserSummaryResponse getUser(@PathVariable String email) {

        appUserEntity user = service.getUserByEmail(email);

        return new UserSummaryResponse(
                user.getEmail(),
                user.getName(),
                user.getMobile(),
                user.getRole() != null ? user.getRole().name() : null,
                user.getActive());
    }
}
