package com.hlms.UserServices.Dto;

import com.hlms.UserServices.Enum.roleEnum;

public class RegisterRequestDTO {

    private String email;
    private String name;
    private String mobile;
    private String password;
    private roleEnum role;
    private String idType;
    private String idNumber;

    public RegisterRequestDTO() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public roleEnum getRole() {
        return role;
    }

    public void setRole(roleEnum role) {
        this.role = role;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }
}