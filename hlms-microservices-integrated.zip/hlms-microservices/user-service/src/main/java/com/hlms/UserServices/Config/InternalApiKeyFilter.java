package com.hlms.UserServices.Config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Guards this service's /internal/** endpoints, which are called by other HLMS
 * microservices (not end users) and therefore skip normal JWT auth. Requests to
 * /internal/** must carry a matching X-Internal-Api-Key header, shared across
 * every HLMS service via Config Server ("hlms.internal.api-key"); anything else
 * on that path is rejected with 403 before it reaches the controller.
 *
 * Implemented as a plain Spring-managed Filter bean (auto-registered by Spring
 * Boot for every request) rather than wired into JwtSecurityConfig's
 * SecurityFilterChain, so the User Service's existing Spring Security
 * configuration/JWT flow stays exactly as it was.
 */
@Component
public class InternalApiKeyFilter extends OncePerRequestFilter {

    @Value("${hlms.internal.api-key:}")
    private String expectedKey;

    @Override
    protected void doFilterInternal(@NonNull HttpServletRequest request,
                                     @NonNull HttpServletResponse response,
                                     @NonNull FilterChain filterChain) throws ServletException, IOException {

        if (request.getRequestURI().startsWith("/internal/")) {
            String provided = request.getHeader("X-Internal-Api-Key");
            if (expectedKey == null || expectedKey.isBlank()
                    || provided == null || !provided.equals(expectedKey)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                response.getWriter().write("Forbidden: missing or invalid internal API key");
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}
