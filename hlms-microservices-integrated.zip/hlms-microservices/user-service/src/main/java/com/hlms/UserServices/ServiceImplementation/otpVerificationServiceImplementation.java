package com.hlms.UserServices.ServiceImplementation;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hlms.UserServices.Entity.otpVerificationEntity;
import com.hlms.UserServices.Exception.InvalidOtpException;
import com.hlms.UserServices.Repository.otpVerificationRepository;
import com.hlms.UserServices.Service.otpVerificationService;

@Service
public class otpVerificationServiceImplementation
        implements otpVerificationService {

    @Autowired
    private otpVerificationRepository repository;

    @Override
    @Transactional
    public String generateOtp(
            String email,
            String purpose) {

        String otp =
                String.valueOf(
                        (int) ((Math.random() * 900000)
                                + 100000));

        otpVerificationEntity entity =
                new otpVerificationEntity();

        entity.setOtpId(
                UUID.randomUUID().toString());

        entity.setEmail(email);

        entity.setOtpCode(otp);

        entity.setPurpose(purpose);

        entity.setExpiresAt(
                LocalDateTime.now()
                        .plusMinutes(5));

        repository.save(entity);

        return otp;
    }

    @Override
    @Transactional
    public String verifyOtp(
            String email,
            String otpCode) {

        otpVerificationEntity otp =
                repository
                        .findByEmailAndOtpCodeAndConsumedFalse(
                                email,
                                otpCode)
                        .orElseThrow(
                                () -> new InvalidOtpException(
                                        "Invalid OTP"));

        if (otp.getExpiresAt()
                .isBefore(LocalDateTime.now())) {

            throw new InvalidOtpException(
                    "OTP Expired");
        }

        otp.setConsumed(true);

        repository.save(otp);

        return "OTP Verified Successfully";
    }
}