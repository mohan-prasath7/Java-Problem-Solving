package com.hlms.legal.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Calls user-service's internal (service-to-service) endpoint. Looks up basic user identity (name, mobile, role) from user-service for an email this service already holds.
 * "user-service" is resolved via Eureka; see FeignClientConfig for the
 * internal API key header that authenticates this call.
 */
@FeignClient(name = "user-service", configuration = FeignClientConfig.class)
public interface UserClient {

    @GetMapping("/internal/users/{email}")
    UserSummaryResponse getUser(@PathVariable("email") String email);
}
