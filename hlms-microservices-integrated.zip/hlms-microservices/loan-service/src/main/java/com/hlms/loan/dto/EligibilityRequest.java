package com.hlms.loan.dto;
import java.math.BigDecimal;
public class EligibilityRequest {
    private BigDecimal monthlyIncome;
    private BigDecimal otherEmis;
    private Integer cibilScore;
    private BigDecimal requestedAmount;
    private Integer tenureYears;
    private BigDecimal interestRate; // annual %, e.g. 8.5

    public BigDecimal getMonthlyIncome() {
        return monthlyIncome;
    }
    public void setMonthlyIncome(BigDecimal monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }
    public BigDecimal getOtherEmis() {
        return otherEmis;
    }
    public void setOtherEmis(BigDecimal otherEmis) {
        this.otherEmis = otherEmis;
    }
    public Integer getCibilScore() {
        return cibilScore;
    }
    public void setCibilScore(Integer cibilScore) {
        this.cibilScore = cibilScore;
    }
    public BigDecimal getRequestedAmount() {
        return requestedAmount;
    }
    public void setRequestedAmount(BigDecimal requestedAmount) {
        this.requestedAmount = requestedAmount;
    }
    public Integer getTenureYears() {
        return tenureYears;
    }
    public void setTenureYears(Integer tenureYears) {
        this.tenureYears = tenureYears;
    }
    public BigDecimal getInterestRate() {
        return interestRate;
    }
    public void setInterestRate(BigDecimal interestRate) {
        this.interestRate = interestRate;
    }
}