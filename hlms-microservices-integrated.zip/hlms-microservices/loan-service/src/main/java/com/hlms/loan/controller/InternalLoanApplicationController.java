package com.hlms.loan.controller;

import com.hlms.loan.entity.LoanApplication;
import com.hlms.loan.repository.LoanApplicationRepository;
import com.hlms.loan.exception.ResourceNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Service-to-service endpoint (not for end users): other microservices call this
 * to resolve basic loan application facts (owner, product, amount, status) for an
 * appId they already hold - e.g. document-service confirming an application exists
 * before accepting an upload, legal-service pulling applicant/property context,
 * repayment-service/notification-service composing a message. Protected by
 * InternalApiKeyFilter instead of the normal JWT filter - see SecurityConfig.
 */
@RestController
@RequestMapping("/internal/applications")
public class InternalLoanApplicationController {

    private final LoanApplicationRepository repository;

    public InternalLoanApplicationController(LoanApplicationRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/{appId}")
    public ApplicationSummaryResponse getApplication(@PathVariable String appId) {
        LoanApplication app = repository.findById(appId)
                .filter(a -> a.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Application not found: " + appId));
        return new ApplicationSummaryResponse(app.getAppId(), app.getTrackingNo(), app.getUserEmail(),
                app.getProductId(), app.getLoanAmount(), app.getStatus(), app.getApplicantName(),
                app.getApplicantMobile());
    }

    public record ApplicationSummaryResponse(String appId, String trackingNo, String userEmail, String productId,
                                              java.math.BigDecimal loanAmount, String status, String applicantName,
                                              String applicantMobile) { }
}
