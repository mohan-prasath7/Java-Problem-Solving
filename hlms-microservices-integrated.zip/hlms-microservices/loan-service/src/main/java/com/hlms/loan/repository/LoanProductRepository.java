package com.hlms.loan.repository;

import com.hlms.loan.entity.LoanProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface LoanProductRepository extends JpaRepository<LoanProduct, String> {
    List<LoanProduct> findByDeletedAtIsNull();
    Optional<LoanProduct> findByProductIdAndDeletedAtIsNull(String productId);
}
