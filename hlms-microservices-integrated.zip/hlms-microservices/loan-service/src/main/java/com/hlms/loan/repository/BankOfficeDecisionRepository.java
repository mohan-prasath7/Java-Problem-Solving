package com.hlms.loan.repository;

import com.hlms.loan.entity.BankOfficeDecision;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface BankOfficeDecisionRepository extends JpaRepository<BankOfficeDecision, Long> {
    Optional<BankOfficeDecision> findByAppIdAndDeletedAtIsNull(String appId);
}
