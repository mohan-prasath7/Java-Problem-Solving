package com.hlms.loan.dto;

import java.math.BigDecimal;

public record ProductRecommendation(
        String productId,
        String name,
        String category,
        BigDecimal interestRate,
        Integer maxTenureYears,
        String maxLtv,
        BigDecimal estimatedEmi,
        String matchReason
) {}
