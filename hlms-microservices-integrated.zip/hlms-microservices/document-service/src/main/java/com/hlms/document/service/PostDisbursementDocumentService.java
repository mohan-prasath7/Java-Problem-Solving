package com.hlms.document.service;
import com.hlms.document.entity.PostDisbursementDocument;
import com.hlms.document.exception.BadRequestException;
import com.hlms.document.exception.ResourceNotFoundException;
import com.hlms.document.repository.PostDisbursementDocumentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
/**
 * Backs feature "9. Post-Disbursement Service Management", specifically US-PD-04
 * Digital Document Exchange (upload/list/download already existed as a table with
 * no service/controller in front of it - this fills that gap, and adds a "share" log
 * so stakeholder-to-stakeholder exchange is auditable via the existing audit_log table).
 */
@Service
public class PostDisbursementDocumentService {
    private final PostDisbursementDocumentRepository repository;
    private final AuditService auditService;
    @Transactional
    public PostDisbursementDocument upload(String appId, String docType, String note, MultipartFile file, String uploadedBy) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("No file was provided.");
        }
        byte[] data;
        try {
            data = file.getBytes();
        } catch (IOException e) {
            throw new BadRequestException("Could not read uploaded file: " + e.getMessage());
        }
        PostDisbursementDocument doc = PostDisbursementDocument.builder()
                .pdDocId("PDD-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase())
                .appId(appId)
                .docType(docType)
                .fileName(file.getOriginalFilename())
                .fileData(data)
                .fileSize((int) file.getSize())
                .note(note)
                .status("Pending")
                .build();
        PostDisbursementDocument saved = repository.save(doc);
        auditService.record("post_disbursement_document", saved.getPdDocId(), "UPLOAD", uploadedBy,
                null, Map.of("appId", appId, "docType", docType, "fileName", saved.getFileName()));
        return saved;
    }
    public List<PostDisbursementDocument> listForApp(String appId) {
        return repository.findByAppIdAndDeletedAtIsNull(appId);
    }
    public PostDisbursementDocument get(String pdDocId) {
        return repository.findById(pdDocId)
                .filter(d -> d.getDeletedAt() == null)
                .orElseThrow(() -> new ResourceNotFoundException("Post-disbursement document not found: " + pdDocId));
    }
    @Transactional
    public PostDisbursementDocument verify(String pdDocId, String status, String verifiedBy, String remarks) {
        PostDisbursementDocument doc = get(pdDocId);
        doc.setStatus(status);
        doc.setVerifiedBy(verifiedBy);
        doc.setVerifiedAt(OffsetDateTime.now());
        doc.setRemarks(remarks);
        return repository.save(doc);
    }
    /** US-PD-04: records that a document was shared with/downloaded by a stakeholder.
     *  There's no separate "share" table (and none may be added) - the exchange itself
     *  is the download endpoint; this just makes each exchange auditable. */
    @Transactional
    public PostDisbursementDocument recordShare(String pdDocId, String sharedWithEmail, String sharedByEmail) {
        PostDisbursementDocument doc = get(pdDocId);
        auditService.record("post_disbursement_document", pdDocId, "SHARED", sharedByEmail,
                null, Map.of("sharedWith", sharedWithEmail, "fileName", doc.getFileName()));
        return doc;
    }

    public PostDisbursementDocumentService(PostDisbursementDocumentRepository repository, AuditService auditService) {
        this.repository = repository;
        this.auditService = auditService;
    }
}