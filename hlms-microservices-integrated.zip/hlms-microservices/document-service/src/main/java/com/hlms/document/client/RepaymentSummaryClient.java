package com.hlms.document.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * Calls repayment-service's internal (service-to-service) endpoint. Checks EMI/default status from repayment-service for an appId this service already holds.
 * "repayment-service" is resolved via Eureka; see FeignClientConfig for the
 * internal API key header that authenticates this call.
 */
@FeignClient(name = "repayment-service", configuration = FeignClientConfig.class)
public interface RepaymentSummaryClient {

    @GetMapping("/internal/repayment/application/{appId}/summary")
    RepaymentSummaryResponse getSummary(@PathVariable("appId") String appId);
}
