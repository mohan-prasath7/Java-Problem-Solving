# Fixes applied in this build

This is the same 9-module `hlms-microservices` project (Eureka, Config Server,
API Gateway, and the 6 business services), with three things fixed project-wide.

## 1. Lombok removed from all 6 business services (Eclipse fix)

Every entity, DTO, controller, service, and config class that used Lombok
(`@Getter`, `@Setter`, `@NoArgsConstructor`, `@AllArgsConstructor`, `@Builder`,
`@RequiredArgsConstructor`, `@Slf4j`) has been rewritten with plain, explicit
Java - hand-written getters/setters, a no-arg constructor, an all-args
constructor, and a `Builder` inner class with the exact same fluent API
(`Xxx.builder().field(value)...build()`) Lombok would have generated, so no
service/controller code that calls `.builder()...build()` needed to change.
`@RequiredArgsConstructor` classes (mostly `SecurityConfig` and Feign client
config classes) got an explicit constructor for their `final` fields instead.
`@Slf4j` was replaced with an explicit
`private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(...)`
field. This applies to **101 files** across `user-service`, `loan-service`,
`document-service`, `legal-service`, `repayment-service`, and
`notification-service`.

The `lombok` dependency (and the matching `spring-boot-maven-plugin` exclude
block) was removed from all 6 services' `pom.xml` files, since nothing in the
code needs it any more. `api-gateway`, `config-server`, and `eureka-server`
never used Lombok, so they're untouched.

**What this fixes:** Lombok only works in Eclipse if the Lombok jar is
installed into Eclipse itself (`java -jar lombok.jar` → point at your
`eclipse.exe` → restart), and it's a very common source of "cannot find
symbol" errors on getters/setters/builders if that step was skipped, done
against the wrong Eclipse install, or the Maven project wasn't refreshed
afterward. Removing the dependency removes that whole failure mode - no
Lombok installation step is needed any more, and every module builds the same
way whether you use Eclipse, IntelliJ, or plain `mvn` from a terminal.

## 2. Database schema: soft-delete fix + v3 folded in

New file: **`sql/hlms_schema_combined_v3_fixed.sql`** replaces both the old
monolith schema file and the separate `sql/schema_additions_v3.sql` add-on.
Run this ONE file against a fresh database - see the README's "Database"
section.

What changed vs. what you had:
- The file's final section ("9. CONVENIENCE VIEWS") was previously cut off
  mid-statement (`CREATE VIEW v_active_loan_appli` with no `AS SELECT ...`,
  no semicolon), which produced `ERROR: syntax error at end of input` in
  psql/pgAdmin. That statement is now completed, and a `v_active_*` view was
  added for every table that has a `deleted_at` column (21 views total).
- `schema_additions_v3.sql`'s two tables (`otp_verification`,
  `eligibility_assessment`) are now folded directly into the main file
  instead of being a second script you had to remember to run - and they now
  also get `v_active_*` views, which the standalone v3 file never had.
- **Soft-delete bug:** the generic `soft_delete()` / `restore_record()`
  functions dynamically `UPDATE ... SET deleted_at = ...` against whatever
  table name they're given. `audit_log` is the one table in the schema that
  deliberately has **no** `deleted_at` column (an audit trail must stay
  permanent), so calling `soft_delete('audit_log', ...)` against it used to
  fail with a bare, confusing `column "deleted_at" does not exist`. Both
  functions now check `information_schema.columns` first and raise a clear
  `soft_delete(): table "audit_log" has no deleted_at column and does not
  support soft delete (it may be an intentionally immutable table, e.g.
  audit_log)` instead.

## 3. ER diagram vs. schema: one intentional difference (please confirm)

`HLMS_ER_Diagram_corrected.pdf` includes a `LOAN_DRAFT` entity
(`draftId`, `userEmail`, `currentStep`, `savedAt`, `loanType`, `loanAmount`,
`tenureYears`, `formData`) as a separate table. **That table does not exist
in the schema or in any service**, by design of the existing code: the
"Draft Saving" story (US-LA-06, `Team_A_Product_Backlog.xlsx` row 35) is
already implemented differently - `POST /api/loan-applications/draft` in
`loan-service` creates/updates a normal `loan_application` row with
`status = "Draft"` and tracks progress via `stageIndex`/`currentStep`, rather
than a separate lightweight `loan_draft` table. Functionally this satisfies
the acceptance criteria ("draft applications should be saved and retrieved
successfully"), but it means the schema doesn't literally match the ER
diagram on this one entity. I left this as-is rather than bolting on a
second, parallel draft-storage mechanism that nothing else in the codebase
would use - let me know if you'd rather have a real `loan_draft` table wired
up to match the diagram exactly.

Everything else in the ER diagram (all other 20 entities/relationships) is
present in the schema and mapped by JPA entities in the corresponding
service. `otp_verification` and `eligibility_assessment` exist in the schema
and code but aren't on the ER diagram - they were added later, for the OTP
login (US-UM-03) and persisted-eligibility-history (US-EL-01) stories.

## 4. Pre-existing boolean-getter bugs found while re-verifying (fixed)

While re-checking the delombok output against real Lombok's naming rules, I
found **12 call sites across all 6 services that would not have compiled even
under real Lombok** - they predate this session's changes:

- `Boolean active`, `Boolean prefSms`, `Boolean prefEmail`, `Boolean prefInapp`
  on `AppUser` (every service has its own copy of this entity), and
  `Boolean consumed` on `OtpVerification`: Lombok generates `isActive()` /
  `isPrefSms()` / `isConsumed()` etc. for `Boolean`/`boolean` fields, **not**
  `getActive()`. `UserPrincipal.java` (one per service) and `UserService`/
  `OtpService` were calling the `get...()` form, which never existed. Fixed
  by changing the 11 call sites to `is...()`.
- `Boolean isRead` on `notification-service`'s `Notification` entity: because
  the field name already starts with `is`, real Lombok collapses the getter
  to `isRead()` rather than `isIsRead()`. My first delombok pass generated
  `isIsRead()`; fixed to `isRead()` (no callers depended on the wrong name,
  but Jackson uses the getter to derive the JSON field name for API
  responses, so this affects your `/api/notifications` response shape too).

I re-audited every `Boolean`/`boolean` field against every `.getXxx()` call
in the same service after this fix and confirmed there are no more
mismatches.
